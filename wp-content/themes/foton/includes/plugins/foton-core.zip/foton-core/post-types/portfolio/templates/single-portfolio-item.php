<?php

get_header();

foton_mikado_get_title();

do_action('foton_mikado_action_before_main_content');

foton_core_get_single_portfolio();

get_footer();