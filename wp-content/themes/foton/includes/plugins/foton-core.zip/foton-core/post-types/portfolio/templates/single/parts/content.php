<div class="mkdf-ps-info-item mkdf-ps-content-item">
    <?php the_content(); ?>
</div>